let canvas;
let aspect;
let gl;
let program;
let isMonkey;
let modLoc;
let thetaLoc;
let vertexShader;
let fragmentShader;
let modelViewMatrix;
let modelViewMatrixLoc;
let projectionMatrix;
let projectionMatrixLoc;
let vBuffer;
let vPosition;
let monkeyBuffer;
let indices = [];
let vertices = [];
let plane = [
    1.0, 0.0, 1.0,
    -1.0, 0.0, 1.0,
    -1.0, 0.0, -1.0,
    1.0, 0.0, -1.0
];
let radius = 2.0;
let theta = 0.0;
let radian = 0.0;
let speed = 0.05;
let phi = 0.0;
let fovy = 65.0;
let near = 0.1;
let far = 9.0;
let eye;
let eyePlus = vec3(0.0, 0.3, -0.38);
let at = vec3(0.0, 0.5, -0.01);
let up = vec3(0.0, 1.0, 0.0);