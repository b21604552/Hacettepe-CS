let draw = function () {
    initDraw();
    drawGround();
    drawMonkey();
    requestAnimationFrame(draw);
};

function loadMonkey() {
    $.get("monkey_head.obj", function(data) {
        let lines = data.split("\n");
        for(let i = 0; i < lines.length; i++){
            let line = lines[i].split(" ");
            if (line[0].localeCompare("v") === 0) {
                vertices.push(parseFloat(line[1])/3);
                vertices.push((parseFloat(line[2])/3) + 0.4);
                vertices.push(parseFloat(line[3])/3);
            } else if (line[0].localeCompare("f") === 0) {
                indices.push(parseInt(line[1]) - 1);
                indices.push(parseInt(line[2]) - 1);
                indices.push(parseInt(line[3]) - 1);
            }
        }
        init();
    },'text');
}

function init() {
    initCanvas();
    initGl();
    initLock();
    initShader();
    initDocument();
    draw();
}

function initShaders(vShdrId, fShdrId ) {
    vertexShader = gl.createShader( gl.VERTEX_SHADER );
    createShader(vShdrId, vertexShader);
    fragmentShader = gl.createShader( gl.FRAGMENT_SHADER );
    createShader(fShdrId, fragmentShader);
    program = gl.createProgram();
    createProgram();
}

function createShader(shaderId, shader) {
    gl.shaderSource(shader, shaderId);
    gl.compileShader(shader);
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
        console.log("Vertex shader failed to compile.  The error log is:" + gl.getShaderInfoLog(shader));
        return -1;
    }
}

function createProgram() {
    gl.attachShader(program, vertexShader);
    gl.attachShader(program, fragmentShader);
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
        console.log("Shader program failed to link. The error log is:" + gl.getProgramInfoLog(program));
        return -1;
    }
}

function drawMonkey() {
    createBuffer(vertices,false);
    assignPosition();
    createBuffer(indices,true)
    setIsMonkey(1.0);
    initUniform();
    drawGraphics(true);
}

function drawGround() {
    createBuffer(plane);
    assignPosition();
    setIsMonkey(0.0);
    initUniform();
    drawGraphics(false);
}

function initCanvas() {
    canvas = document.getElementById("gl-canvas");
    canvas.width  = window.innerWidth;
    canvas.height = window.innerHeight;
    aspect = canvas.width / canvas.height;
}

function initGl() {
    gl = canvas.getContext('webgl2');
    if (!gl) {
        alert("WebGL isn't available");
    }

    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.clearColor(1.0, 1.0, 1.0, 1.0);
    gl.enable(gl.DEPTH_TEST);

    initShaders(domShaderSrc("vertex_shader"), domShaderSrc("fragment_shader"));
    gl.useProgram(program);
}

function initLock() {
    canvas.requestPointerLock = canvas.requestPointerLock || canvas.mozRequestPointerLock;
    document.exitPointerLock = document.exitPointerLock || document.mozExitPointerLock;
}

function initShader() {
    modelViewMatrixLoc = gl.getUniformLocation(program, "modelViewMatrix");
    projectionMatrixLoc = gl.getUniformLocation(program, "projectionMatrix");
    modLoc = gl.getUniformLocation(program, "isMonkey");
    thetaLoc = gl.getUniformLocation( program, "theta" );
}

function initDocument() {
    document.addEventListener('pointerlockchange', lockChangeAlert, false);
    document.addEventListener('mozpointerlockchange', lockChangeAlert, false);
    window.onkeydown = input;
}

function initDraw() {
    canvas.width  = window.innerWidth;
    canvas.height = window.innerHeight;
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    eye = vec3(radius * Math.sin(theta) * Math.cos(phi) + eyePlus[0], radius * Math.sin(theta) * Math.sin(phi) + eyePlus[1], radius * Math.cos(theta) + eyePlus[2]);
    modelViewMatrix = lookAt(eye, at, up);
    projectionMatrix = perspective(fovy, aspect, near, far);
    radian += speed;
    gl.uniform1f( thetaLoc, radian );
}

function input(event) {
    switch (event.keyCode) {
        case 69: {
            if (document.pointerLockElement === canvas)
                document.exitPointerLock();
            else
                canvas.requestPointerLock();
            break;
        }case 38: {
            changeCamera(2,-0.01);
            break;
        }case 40: {
            changeCamera(2,0.01);
            break;
        }case 39: {
            changeCamera(0,0.01);
            break;
        }case 37: {
            changeCamera(0,-0.01);
            break;
        }case 33: {
            changeCamera(1,0.01);
            break;
        }case 34: {
            changeCamera(1,-0.01);
            break;
        }case 107: {
            changeRotationSpeed(0.01)
            break;
        }case 109: {
            changeRotationSpeed(-0.01)
            break;
        }
    }
}

function changeCamera(i,value){
    eyePlus[i] += value;
    at[i] += value;
}

function changeRotationSpeed(value){
    speed += value;
}

function createBuffer(data, isMonkey) {
    if(isMonkey){
        monkeyBuffer = gl.createBuffer();
        gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, monkeyBuffer);
        gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint32Array(data), gl.STATIC_DRAW);
    }else{
        vBuffer = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, vBuffer);
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(data), gl.STATIC_DRAW);
    }
}

function assignPosition() {
    vPosition = gl.getAttribLocation(program, "vPosition");
    gl.vertexAttribPointer(vPosition, 3, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vPosition);
}

function initUniform() {
    gl.uniform1f (modLoc,isMonkey);
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
    gl.uniformMatrix4fv(projectionMatrixLoc, false, flatten(projectionMatrix));
}

function setIsMonkey(value) {
    isMonkey = value;
}

function drawGraphics(isMonkey) {
    if(isMonkey)
        gl.drawElements( gl.TRIANGLES, indices.length, gl.UNSIGNED_INT, 0);
    else
        gl.drawArrays(gl.TRIANGLE_FAN, 0, 4);
}

function lockChangeAlert() {
    if (document.pointerLockElement === canvas || document.mozPointerLockElement === canvas)
        document.addEventListener("mousemove", updateView, false);
    else
        document.removeEventListener("mousemove", updateView, false);
}

function updateView(e) {
    theta += (Math.PI / 180 * e.movementX)/20;
    phi += (Math.PI / 180 * e.movementY)/20;
}

function domShaderSrc(elmID) {
    let elm = document.getElementById(elmID);
    if(!elm || elm.text === ""){
        console.log(elmID + " shader not found or no text.");
        return null;
    }
    return elm.text;
}