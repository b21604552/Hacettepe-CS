class Render{
    constructor(callback){
        let self = this;
        this.msLastFrame = null;
        this.callBack = callback;

        this.run = function(){
            let msCurrent = performance.now();
            let deltaTime = (msCurrent - self.msLastFrame) / 1000.0;
            self.fps = Math.floor(1/deltaTime);
            self.msLastFrame = msCurrent;
            self.callBack(deltaTime);
            window.requestAnimationFrame(self.run);
        }
    }

    start(){
        this.msLastFrame = performance.now();
        window.requestAnimationFrame(this.run);
        return this;
    }
}

class ShaderUtil{
    static start(canvasID, newScale) {
        ShaderUtil.initGL(canvasID, newScale);
        ShaderUtil.initProgram(ShaderUtil.createProgram());
        new Render(ShaderUtil.onRender).start();
    }

    static initGL(canvasID, newScale){
        const canvas = document.getElementById(canvasID);
        gl = canvas.getContext("webgl2");

        if(!gl){
            console.error("WebGL context is not available.");
            return null;
        }

        scale = newScale;

        ShaderUtil.scaleDraw()
        ShaderUtil.clear();
    }

    static domShaderSrc(elmID){
        let elm = document.getElementById(elmID);
        if(!elm || elm.text === ""){
            console.log(elmID + " shader not found or no text.");
            return null;
        }
        return elm.text;
    }

    static createShader(src,type){
        let shader = gl.createShader(type);
        gl.shaderSource(shader,src);
        gl.compileShader(shader);

        if(!gl.getShaderParameter(shader, gl.COMPILE_STATUS)){
            console.error("Error compiling shader : " + src, gl.getShaderInfoLog(shader));
            gl.deleteShader(shader);
            return null;
        }
        return shader;
    }

    static createProgram(){
        let vertexShader = ShaderUtil.createShader(ShaderUtil.domShaderSrc("vertex_shader"), gl.VERTEX_SHADER);
        let fragmentShader = ShaderUtil.createShader(ShaderUtil.domShaderSrc("fragment_shader"), gl.FRAGMENT_SHADER);
        let program = gl.createProgram();
        gl.attachShader(program, vertexShader);
        gl.attachShader(program, fragmentShader);
        gl.linkProgram(program);
        if(!gl.getProgramParameter(program, gl.LINK_STATUS) ) {
            let info = gl.getProgramInfoLog(program);
            console.error("Could not link WebGL2 program :" + info);
            return;
        }
        return program;
    }

    static getLocations(program) {
        colorLocation = gl.getAttribLocation(program, "a_color");
        vertexLocation = gl.getAttribLocation(program, "a_position");
        uniformAngle = gl.getUniformLocation(program,"uAngle");
        uniformTransformationMatrix = gl.getUniformLocation(program,"uTransformationMatrix");
        uniformColor = gl.getUniformLocation(program,"uniformColor");
        uniqueId = gl.getUniformLocation(program,"uniqueId");
    }

    static initProgram(program) {
        ShaderUtil.addEventListeners();
        ShaderUtil.getLocations(program);
        gl.useProgram(program);
    }

    static buffer(shape, shape_color) {
        const buffer = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(shape.concat(shape_color)), gl.STATIC_DRAW);
        gl.bufferSubData(gl.ARRAY_BUFFER, 0, new Float32Array(shape));
        gl.bufferSubData(gl.ARRAY_BUFFER, shape.length *4, new Float32Array(shape_color));
        return buffer;
    }

    static drawShape(shape, shape_buffer, shape_mode, vertex_number, elementID) {
        gl.uniform1i(uniqueId,elementID);
        gl.bindBuffer(gl.ARRAY_BUFFER, shape_buffer);
        gl.vertexAttribPointer(vertexLocation, 2, gl.FLOAT, false, 0, 0);
        gl.enableVertexAttribArray(vertexLocation);
        gl.enableVertexAttribArray(colorLocation);
        gl.vertexAttribPointer(colorLocation, 3, gl.FLOAT, false, 0, shape.length * 4);
        gl.drawArrays(shape_mode, 0, vertex_number);
    }

    static clear() {
        gl.clearColor(1.0, 1.0, 1.0, 1.0);
        gl.clear(gl.COLOR_BUFFER_BIT);
    }

    static getConcatData(radius, centers, j, i=0) {
        return [radius * Math.cos(j * radian) + centers[i][0], radius * Math.sin(j * radian) + centers[i][1]]
    }

    static createYellowCircleArray() {
        let circleArray = [[]];
        for (let j = 0; j < 360; j++) {
            circleArray[0] = circleArray[0].concat(ShaderUtil.getConcatData(yellowCircleRadius, yellowCirclePoints, j));
        }
        return circleArray
    }

    static createBlackCircleArray() {
        let circleArray=[[],[]];
        for(let i=0;i<2;i++){
            for (let j = 0; j < 360; j++) {
                circleArray[i] = circleArray[i].concat(ShaderUtil.getConcatData(blackCircleRadius, blackCirclePoints, j, i));
            }
        }
        return circleArray;
    }

    static createColorArray(color, loop){
        let colorArray = [];
        for(let i = 0; i < loop; i++) {
            colorArray = colorArray.concat(color);
        }
        return colorArray;
    }

    static quadraticBezier(p0, p1, p2, t) {
        let x = Math.pow(1 - t, 2) * p0.x + (1 - t) * 2 * t * p1.x + t * t * p2.x,
            y = Math.pow(1 - t, 2) * p0.y + (1 - t) * 2 * t * p1.y + t * t * p2.y;
        return [x,y];
    }

    static getCurvePositions(p0,p1,p2){
        let curvePositions = []
        for(let t = 0 ; t < 1; t = t + 0.0005 ){
            curvePositions = curvePositions.concat(ShaderUtil.quadraticBezier(p0,p1,p2,t));
        }
        return curvePositions;
    }

    static drawFace(){
        let yellowCircleArray = ShaderUtil.createYellowCircleArray(),
            yellowCircle = ShaderUtil.createColorArray([0.929,0.831,0.09],360),
            yellowCircleBuffers = [];
        yellowCircleBuffers = yellowCircleBuffers.concat(ShaderUtil.buffer(yellowCircleArray[0], yellowCircle));

        ShaderUtil.drawShape(yellowCircleArray[0], yellowCircleBuffers[0], gl.TRIANGLE_FAN, 360, shapeIds.face);
    }

    static getYellowColor(){
        if(rotateAngle === 0){
            colorStep = 0;
        }else if(colorTransfer && rotateAngle >= 0 && turn === 0){
            colorStep -= 0.006;
        }else if(colorTransfer && rotateAngle < 0 && turn === 0){
            colorStep += 0.006;
        }else if(colorTransfer && rotateAngle > 0 && turn === 1){
            colorStep += 0.006;
        }else if(colorTransfer && rotateAngle <= 0 && turn === 1){
            colorStep -= 0.006;
        }
    }

    static drawEyes(){
        let blackCircleArray = ShaderUtil.createBlackCircleArray(),
            blackCircle = ShaderUtil.createColorArray([0.231,0.212,0.078],360),
            blackCircleBuffers = [];

        for (let i = 0; i < 2; i++){
            blackCircleBuffers = blackCircleBuffers.concat(ShaderUtil.buffer(blackCircleArray[i],blackCircle));
        }

        for (let i = 0; i < 2; i++){
            ShaderUtil.drawShape(blackCircleArray[i],blackCircleBuffers[i],gl.TRIANGLE_FAN,360,shapeIds.eyes);
        }
    }

    static drawMask(){
        let squareColorArray = ShaderUtil.createColorArray([0.839,0.878,0.922],4),
            squareCornerColorArray = ShaderUtil.createColorArray([0.839,0.878,0.922],4),
            squareCornersBuffers = [],
            squareBuffers;

        for (let i = 0; i < 4; i++){
            squareCornersBuffers = squareCornersBuffers.concat(ShaderUtil.buffer(squareCorners[i],squareCornerColorArray));
        }

        squareBuffers = ShaderUtil.buffer(square,squareColorArray);

        ShaderUtil.drawShape(square,squareBuffers,gl.TRIANGLE_STRIP,4,shapeIds.mask);
        ShaderUtil.drawMaskCorners(squareCornersBuffers,4);
    }

    static drawMaskCorners(buffer,loop){
        for (let i = 0; i < loop; i++){
            ShaderUtil.drawShape(squareCorners[i],buffer[i],gl.TRIANGLE_STRIP,4,shapeIds.maskCorners);
        }
    }

    static drawCurves(){
        let curveColorArray = ShaderUtil.createColorArray([0.839,0.878,0.922],2000),
            curveTopPositionsBuffer = [],
            curveBottomPositionsBuffer = [],
            curveTopPositions,
            curveBottomPositions;

        curveTopPositions = ShaderUtil.getCurvePositions(curves.top.p0,curves.top.p1,curves.top.p2);
        curveBottomPositions = ShaderUtil.getCurvePositions(curves.bottom.p0,curves.bottom.p1,curves.bottom.p2);
        curveTopPositionsBuffer = curveTopPositionsBuffer.concat(ShaderUtil.buffer(curveTopPositions,curveColorArray));
        curveBottomPositionsBuffer = curveBottomPositionsBuffer.concat(ShaderUtil.buffer(curveBottomPositions,curveColorArray));

        ShaderUtil.drawShape(curveTopPositions,curveTopPositionsBuffer[0],gl.TRIANGLE_FAN,2000,shapeIds.topCurve);
        ShaderUtil.drawShape(curveBottomPositions,curveBottomPositionsBuffer[0],gl.TRIANGLE_FAN,2000,shapeIds.bottomCurve);
    }

    static scaleDraw(){
        yellowCircleRadius = yellowCircleRadius * scale;
        blackCircleRadius = blackCircleRadius * scale;
        this.scaleArray(yellowCirclePoints);
        this.scaleArray(blackCirclePoints);
        this.scaleArray(squareCorners);
        this.scaleArray(square);
        this.scaleCurves();
    }

    static scaleArray(array){
        for (let i = 0; i < array.length; i++){
            if(array[i].length > 1){
                for (let j = 0; j < array[i].length; j++){
                    array[i][j] = array[i][j] * scale
                }
            }else{
                array[i] = array[i] * scale
            }
        }
    }

    static scaleCurves(){
        curves.top.p0.x *= scale;
        curves.top.p0.y *= scale;
        curves.top.p1.x *= scale;
        curves.top.p1.y *= scale;
        curves.top.p2.x *= scale;
        curves.top.p2.y *= scale;
        curves.bottom.p0.x *= scale;
        curves.bottom.p0.y *= scale;
        curves.bottom.p1.x *= scale;
        curves.bottom.p1.y *= scale;
        curves.bottom.p2.x *= scale;
        curves.bottom.p2.y *= scale;
    }

    static drawScene(){
        gl.uniform1f(uniformAngle,angle);
        gl.uniform1f(uniformColor,colorStep);
        gl.uniformMatrix4fv(uniformTransformationMatrix,false, ShaderUtil.getTransformationMatrix());
        ShaderUtil.clear();
        ShaderUtil.drawFace();
        ShaderUtil.drawEyes();
        ShaderUtil.drawMask();
        ShaderUtil.drawCurves();
    }

    static onRender(dt){
        if(animation){
            ShaderUtil.getAngle(dt);
            ShaderUtil.getYellowColor();
        }
        ShaderUtil.drawScene();
    }

    static getAngle(dt){
        if(rotateAngle < 45 && turn === 0){
            turn = 0;
            rotateAngle += 1;
            angle += angleStep * dt;
        }else if(rotateAngle >= 45 && turn === 0){
            turn = 1;
            rotateAngle -= 1;
            angle -= angleStep * dt;
        }else if(rotateAngle > -45 && turn === 1){
            turn = 1;
            rotateAngle -= 1;
            angle -= angleStep * dt;
        }else if(rotateAngle <= -45 && turn === 1){
            turn = 0;
            rotateAngle += 1;
            angle += angleStep * dt;
        }
    }

    static resetAngle(){
        angle = 1.50;
        turn = 0;
        rotateAngle = 0;
        colorStep = 0;
    }

    static getTransformationMatrix(){
        let radianTransformation = Math.PI * rotateAngle / 180;
        let cosB = Math.cos(radianTransformation);
        let sinB = Math.sin(radianTransformation);
        return new Float32Array([cosB,+sinB,0,0,-sinB,cosB,0,0,0,0,1,0,0,0,0,1]);
    }

    static addEventListeners(){
        document.addEventListener("keypress", (event) => this.parsePressedKey(event.key));
    }

    static parsePressedKey(key){
        switch(parseInt(key)) {
            case keys.step1:
                ShaderUtil.resetAngle()
                animation = false;
                colorTransfer = false;
                break;
            case keys.step2:
                ShaderUtil.resetAngle()
                animation = true;
                colorTransfer = false;
                break;
            case keys.step3:
                ShaderUtil.resetAngle()
                animation = true;
                colorTransfer = true;
                break;
            default:
                return null
        }
    }
}