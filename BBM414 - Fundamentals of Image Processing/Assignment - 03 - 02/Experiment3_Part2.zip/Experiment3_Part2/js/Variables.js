//Constants
const radian = Math.PI / 180;

//Rotate and Scaling Variables
let uniformAngle = -180;
let uniformTransformationMatrix;
let uniqueId;
let uniformColor;
let turn = 0;
let angle = 1.50;
let colorStep = 0;
let angleStep = radian * 45;
let animation = false;
let spinSpeed = 1;
let spiralSpeed = 1;
let spiralTurn = 0;
let scalingDirection = true;
let scalingAnimation = false;
let spiralAnimation = false;
let spin = false;
let rotateAngle = 0;
let colorTransfer = false;
let scale = 1;
let uPosition = 0.0;
let uniformPosition;
let shapeIds = {
    face: 0,
    eyes: 1,
    mask: 2,
    maskCorners: 3,
    topCurve: 4,
    bottomCurve: 5
}

//Global Variables
let vertexLocation;
let colorLocation;
let gl;

//Keys For Steps
let keys = {
    step1: 1,
    step2: 2,
    step3: 3,
}

//Drawing Emoji
let yellowCircleRadius = 0.6;
let blackCircleRadius = 0.1;
let yellowCirclePoints = [[0.0, 0.0]];
let blackCirclePoints = [[0.2,0.2],[-0.2,0.2]];
let squareCorners = [
    [-0.6, 0.05, -0.3, -0.05, -0.6, -0.0, -0.3, -0.1],
    [0.6, 0.05, 0.3, -0.05, 0.6, -0.0, 0.3, -0.1],
    [-0.3, -0.45, -0.35, -0.489, -0.3, -0.4, -0.4, -0.45],
    [0.3, -0.45, 0.35, -0.489, 0.3, -0.4, 0.4, -0.45]];
let square = [-0.3, -0.05, 0.3, -0.05, -0.3, -0.45, 0.3, -0.45];
let curves = {
    top: {
        p0: {x:-0.3,y:-0.05},
        p1: {x:0.0,y:0.15},
        p2: {x:0.3,y:-0.05},
    },
    bottom: {
        p0: {x:-0.3,y:-0.45},
        p1: {x:0.0,y:-0.55},
        p2: {x:0.3,y:-0.45},
    }
}