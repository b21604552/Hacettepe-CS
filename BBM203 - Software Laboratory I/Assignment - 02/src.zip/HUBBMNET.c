#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
int NumberOfHops = 0;
int MessageDrop = 0;
struct Layer{
	char *LayerType;
	char *Area1;
	char *Area2;
	char *Area3;
};
struct Stack{
    struct Layer Layers[4];
    int top;
};
struct Log{
	int LogID;
	char* Message;
	int NumberOfFrames;
	int NumberOfHops;
	char* Sender;
	char* Receiver;
	char* Activity;
	char* Succes;
	char* YMDDate;
};
struct Queue{
    struct Stack Stacks;
    struct Queue *Next;
};
struct LogQueue{
    struct Log Logs;
    struct LogQueue *Next;
};
struct Clients {
    char* Name;
    char* Ip;
    char* Mac;
    int totalLog;
    struct LogQueue *LogsFront;
    struct LogQueue *LogsRear;
    struct Queue *IQueueFront;
    struct Queue *IQueueRear;
    struct Queue *OQueueFront;
    struct Queue *OQueueRear;
};
struct Routings{
	char *Name;
	char *Destination;
	char *NextStop;
};
/*Those functions all about getting data from files.*/
int getTotalClient(char* filePath);
int getTotalCommands(char* filePath);
void getClientData(struct Clients *ClientsData, char* filePath);
void getRoutingData(struct Routings *RoutingsData, struct Clients *ClientsData, char* filePath, int totalClient);
/*Those functions all about client process.*/
struct Clients *searchClients(struct Clients *ClientsData, char* SearchingClient, int totalClient);
struct Clients searchClientsByValue(struct Clients *ClientsData, char* SearchingClient, int totalClient);
struct Clients *searchClientsByIP(struct Clients *ClientsData, char* SearchingClient, int totalClient);
struct Clients *searchClientsByMac(struct Clients *ClientsData, char* SearchingClient, int totalClient);
void InitClientFrontAndRear(struct Clients *Client);
/*Those functions all about stack process.*/
void IntoTheStack(struct Layer Layers[4],struct Stack *MessageStacks,int totalPart);
void Push(struct Stack *MessageStacks, struct Layer Layers);
void Pop(struct Stack *MessageStacks);
void Display(struct Stack *MessageStacks);
void Init(struct Stack *MessageStacks);
struct Layer Peek(struct Stack *MessageStacks);
char *PeekIP(struct Stack *Stacks);
struct Layer PeekAppLayer(struct Stack *Stacks);
struct Layer PopAllStackAndReturnAppLayer(struct Stack *Stacks);
void changeMacAdress(struct Stack *Stacks,char *Rmac,char *Nmac);
/*Those functions all logs process.*/
struct Log *CreateLog(struct Clients *Client, char* Message, int NumberOfFrames, int NumberOfHops, char* Sender, char* Receiver, char* Activity, char* Succes);
void InsertLog(struct Clients *Client, struct Log *Log);
void DisplayLogs(struct Clients *Client);
/*Those functions all about queue process.*/
void InsertToInQueue(struct Clients *Client, struct Stack *Stacks2);
void InsertToOutQueue(struct Clients *Client, struct Stack *Stacks2);
int DisplayInQueue(struct Clients *Client);
int DisplayOutQueue(struct Clients *Client);
struct Clients *IncomingToOutgoing(struct Clients *Reciver,struct Clients *FinalClient,struct Routings *RoutingsData,struct Clients *ClientsData,int totalClient, int MaxMsgSize);
void OutgoingToIncoming(struct Clients *Sender,struct Clients *Reciver);
struct Stack *PeekFirstFrame(struct Clients *Client);
/*Other Functions*/
void printDash(int j);
char* findRouting(struct Routings *RoutingsData,int totalClient , char* Sender, char* Receiver);
void processingOfCommands(struct Routings *RoutingsData, struct Clients *ClientsData, char* filePathOfCommands, char* filePathOfClients, char* MaxMsgSize, char* outPort, char* inPort);
void MessageSendingUntilEnd(struct Clients *ClientsData, struct Clients *ReceiverClient, int totalClient, struct Routings *RoutingsData, int MaxMsgSize);

int main(int argc, char **argv){
	int totalClient = getTotalClient(argv[1]);
	struct Clients *ClientsData = malloc(totalClient * sizeof(struct Clients));
	struct Routings *RoutingsData = malloc(totalClient * sizeof(struct Clients));
	getClientData(ClientsData,argv[1]);
	getRoutingData(RoutingsData, ClientsData, argv[2], totalClient);
	processingOfCommands(RoutingsData,ClientsData,argv[3],argv[1],argv[4],argv[5],argv[6]);
}
/* This function print-out dash character as long as given input.*/
void printDash(int j){
	int i;
	for (i = 0; i < j; ++i){
		printf("-");
	}
	printf("\n");
}
/* This function create log records, as log struct.*/
struct Log *CreateLog(struct Clients *Client,char* Message, int NumberOfFrames, int NumberOfHops, char* Sender, char* Receiver, char* Activity, char* Succes){
	struct Log *NewLog = (struct Log*)malloc(sizeof(struct Log));
	NewLog->LogID = ++(Client->totalLog);
	NewLog->Message = strdup(Message);
	time_t Now;
    time(&Now);
    struct tm* NowTm;
    NowTm = localtime(&Now);
    char *Date = calloc(22, sizeof(char*));
    strftime (Date, 22, "%Y-%m-%d %H:%M:%S", NowTm);
	NewLog->YMDDate = Date;
	NewLog->NumberOfFrames = NumberOfFrames;
	NewLog->NumberOfHops = NumberOfHops;
	NewLog->Sender = Sender;
	NewLog->Receiver = Receiver;
	NewLog->Activity = Activity;
	NewLog->Succes = Succes;
	return NewLog;
}
/* This function print-out log records of given client.*/
void DisplayLogs(struct Clients *Client){
	struct LogQueue *Temp;
    Temp = Client->LogsFront;
    char* Header = malloc(sizeof(char));
    while (Temp != NULL){
    	sprintf(Header, "Log Entry #%d:",Temp->Logs.LogID);
    	printDash((strlen(Header)) + 1);
    	printf("%s\n", Header);
    	printf("Timestamp: %s\n",Temp->Logs.YMDDate);
    	printf("Message: %s\n",Temp->Logs.Message);
    	printf("Number of frames: %d\n",Temp->Logs.NumberOfFrames);
    	printf("Number of hops: %d\n",Temp->Logs.NumberOfHops);
    	printf("Sender ID: %s\n",Temp->Logs.Sender);
    	printf("Receiver ID: %s\n",Temp->Logs.Receiver);
    	printf("Activity: %s\n",Temp->Logs.Activity);
    	printf("Success: %s\n",Temp->Logs.Succes);
        Temp = Temp->Next;
    }
    free(Header);
}
/* This function insert log files to log queue which is dynamic linked list.*/
void InsertLog(struct Clients *Client, struct Log *Log){
	struct LogQueue *Temp = (struct LogQueue*)malloc(sizeof(struct LogQueue));
    Temp->Logs = *Log;
    Temp->Next = NULL;
    if (Client->LogsRear  ==  NULL){
        Client->LogsFront = Client->LogsRear = Temp;
    }else{
        Client->LogsRear->Next = Temp;
        Client->LogsRear = Client->LogsRear->Next;
    }
}
/* This function returns total client from file.*/
int getTotalClient(char* filePath){
	FILE *clientsFile;
	clientsFile = fopen(filePath, "r");
	char line[100];
	int totalClient;
	while ( fgets ( line, sizeof line, clientsFile ) != NULL ){	
			totalClient = atoi(line);
			break;
	}
	fclose(clientsFile);
	return totalClient;
}
/* This function gets clients data from file*/
void getClientData(struct Clients *ClientsData, char* filePath){
	FILE *clientsFile;
	clientsFile = fopen(filePath, "r");
	char line[255];
	int control = 0,i = 0;
	while ( fgets ( line, sizeof line, clientsFile ) != NULL ){
		line [strcspn(line, "\r\n")] = 0;
		if (control !=0){
			char *temp = strtok(line, " ");
			ClientsData[i].Name = strdup(temp);
			temp = strtok (NULL, " ");
			ClientsData[i].Ip = strdup(temp);
			temp = strtok (NULL, " ");
			ClientsData[i].Mac = strdup(temp);
			ClientsData[i].totalLog = 0;
			InitClientFrontAndRear(&ClientsData[i]);
			i++;
		}else{
			control=1;
		}		
	}
}
/* This function gets routing data from file.*/
void getRoutingData(struct Routings *RoutingsData, struct Clients *ClientsData, char* filePath, int totalClient){
	FILE *clientsFile;
	clientsFile = fopen(filePath, "r");
	char line[255];
	int i;
	char **ClientsNames = calloc(totalClient, sizeof(char*));
	for(i = 0 ; i < totalClient ; i++){
   		ClientsNames[i] = calloc(1, sizeof(char)*5);
	}
	char *Destination, *NextStop;
	int control = 0,j = 0;
	for (i = 0; i < totalClient; ++i){
		ClientsNames[i] = ClientsData[i].Name;
	}
	i = 0;
	while ( fgets ( line, sizeof line, clientsFile ) != NULL ){
		line [strcspn(line, "\r\n")] = 0;
		Destination = strtok (line," ");
		NextStop = strtok(NULL," ");
		if(strcmp(line,"-") == 0){
			i++;
		}else{
			RoutingsData[j].Name = ClientsNames[i];
			RoutingsData[j].Destination = strdup(Destination);
			RoutingsData[j].NextStop = strdup(NextStop);
			j++;
		}	
	}
}
/* This function gets total commands from file.*/
int getTotalCommands(char* filePath){
	FILE *commandFile;
	commandFile = fopen(filePath, "r");
	char line[100];
	int totalCommands;
	while ( fgets ( line, sizeof line, commandFile ) != NULL ){	
			totalCommands = atoi(line);
			break;
	}
	return totalCommands;
}
/* This function find route from between two clients.*/
char* findRouting(struct Routings *RoutingsData,int totalClient, char* Sender, char* Receiver){
	int i;
	char* NextStop = "No Way!";
	for (i = 0; i < (totalClient * (totalClient-1)); ++i){
		if((strcmp(RoutingsData[i].Name, Sender) == 0) && (strcmp(RoutingsData[i].Destination, Receiver) == 0)){
			NextStop = RoutingsData[i].NextStop;
		}
	}
	return NextStop;
}
/* This function search a client according to name.*/
struct Clients *searchClients(struct Clients *ClientsData, char* SearchingClient, int totalClient){
	int i;
	for (i = 0; i < totalClient; ++i)
	{
		if(strcmp(ClientsData[i].Name, SearchingClient) == 0){
			return &ClientsData[i];
		}
	}
}
/* This function search a client according to name, but it does not returns a pointer, it returns copy of it.*/
struct Clients searchClientsByValue(struct Clients *ClientsData, char* SearchingClient, int totalClient){
	int i;
	for (i = 0; i < totalClient; ++i)
	{
		if(strcmp(ClientsData[i].Name, SearchingClient) == 0){
			return ClientsData[i];
		}
	}
}
/* This function search a client according to mac adress*/
struct Clients *searchClientsByMac(struct Clients *ClientsData, char* SearchingClient, int totalClient){
	int i;
	for (i = 0; i < totalClient; ++i)
	{
		if(strcmp(ClientsData[i].Mac, SearchingClient) == 0){
			return &ClientsData[i];
		}
	}
}
/* This function search a client according to IP adress*/
struct Clients *searchClientsByIP(struct Clients *ClientsData, char* SearchingClient, int totalClient){
	int i;
	for (i = 0; i < totalClient; ++i)
	{
		if(strcmp(ClientsData[i].Ip, SearchingClient) == 0){
			return &ClientsData[i];
		}
	}
}
/* This function add a set of layer into stack using push.*/
void IntoTheStack(struct Layer Layers[4],struct Stack *MessageStacks,int totalPart){
	int j;
	Init(MessageStacks);
	for (j = 0; j < 4; ++j){
			Push(MessageStacks,Layers[j]);
	}
}
/* This function initilazie stacks top to -1.*/
void Init(struct Stack *MessageStacks){
	MessageStacks->top = -1;
}
/* This function returns top layer of stack.*/
struct Layer Peek(struct Stack *MessageStacks){
	return MessageStacks->Layers[MessageStacks->top];
}
/* This function pop the top layer of stack.*/
void Pop(struct Stack *MessageStacks){
	if(MessageStacks->top == -1){
		printf("Error: Stack is Empty.\n");
	}else{
		MessageStacks->top--;
	}
}
/* This function push a layer on top of stack.*/
void Push(struct Stack *MessageStacks, struct Layer Layers){
	if(MessageStacks->top == 3){
		printf("Error: Stack is Full.\n");
	}else{
		MessageStacks->Layers[++MessageStacks->top] = Layers;
	}
}
/* This function print-out a stack.*/
void Display(struct Stack *MessageStacks){
	int i;
	if(MessageStacks->top != -1){
		for (i = MessageStacks->top; i >= 0; --i){
			switch(i){
				case 3:
					printf("Sender MAC address: %s, Receiver MAC address: %s\n", MessageStacks->Layers[i].Area1, MessageStacks->Layers[i].Area2);
				break;
				case 2:
					printf("Sender IP address: %s, Receiver IP address: %s\n", MessageStacks->Layers[i].Area1, MessageStacks->Layers[i].Area2);
				break;
				case 1:
					printf("Sender port number: %s, Receiver port number: %s\n", MessageStacks->Layers[i].Area1, MessageStacks->Layers[i].Area2);
				break;
				case 0:
					printf("Sender ID: %s, Receiver ID: %s\nMessage chunk carried: %s\n", MessageStacks->Layers[i].Area1, MessageStacks->Layers[i].Area2, MessageStacks->Layers[i].Area3);
				break;
			}
		}
	}
}
/* This function initialize all the queue pointers of a client.*/
void InitClientFrontAndRear(struct Clients *Client){
	Client->IQueueFront = NULL;
	Client->IQueueRear = NULL;
	Client->OQueueFront = NULL;
	Client->OQueueRear = NULL;
	Client->LogsFront = NULL;
	Client->LogsRear = NULL;
}
/* This function returns total frames in in-queue.*/
int DisplayInQueue(struct Clients *Client){
	struct Queue *Temp;
    Temp = Client->IQueueFront;
    int counter = 0;
    while (Temp != NULL){
    	counter++;
        Temp = Temp->Next;
    }
    return counter;
}
/* This function returns total frames in out-queue.*/
int DisplayOutQueue(struct Clients *Client){
	struct Queue *Temp;
    Temp = Client->OQueueFront;
    int counter = 0;
    while (Temp != NULL){
    	counter++;
        Temp = Temp->Next;
    }
    return counter;
}
/* This function insert into in-queue.*/
void InsertToInQueue(struct Clients *Client, struct Stack *Stacks2){
    struct Queue *Temp = (struct Queue*)malloc(sizeof(struct Queue));
    Temp->Stacks = *Stacks2;
    Temp->Next = NULL;
    if (Client->IQueueRear  ==  NULL){
        Client->IQueueFront = Client->IQueueRear = Temp;

    }else{
        Client->IQueueRear->Next = Temp;
        Client->IQueueRear = Client->IQueueRear->Next;
    }
}
/* This function insert into out-queue.*/
void InsertToOutQueue(struct Clients *Client, struct Stack *Stacks2){
    struct Queue *Temp = (struct Queue*)malloc(sizeof(struct Queue));
    Temp->Stacks = *Stacks2;
    Temp->Next = NULL;
    if (Client->OQueueRear  ==  NULL){
        Client->OQueueFront = Client->OQueueRear = Temp;

    }else{
        Client->OQueueRear->Next = Temp;
        Client->OQueueRear = Client->OQueueRear->Next;
    }
}
/* This function returns top frame of out-queue.*/
struct Stack *PeekFirstFrame(struct Clients *Client){
    return &(Client->OQueueFront->Stacks);
}
/* This function returns IP adress of network layer.*/
char *PeekIP(struct Stack *Stacks){
	struct Layer LayerOnTop = Peek(Stacks);
	Pop(Stacks);
	struct Layer Layer = Peek(Stacks);
	Push(Stacks,LayerOnTop);
	return Layer.Area2;
}
/* This function unpack all the layers of frame and returns application layer for accessing message chunk.*/
struct Layer PopAllStackAndReturnAppLayer(struct Stack *Stacks){
	struct Layer Layer1FromTop = Peek(Stacks);
	Pop(Stacks);
	struct Layer Layer2FromTop = Peek(Stacks);
	Pop(Stacks);
	struct Layer Layer3FromTop = Peek(Stacks);
	Pop(Stacks);
	struct Layer Layer4FromTop = Peek(Stacks);
	Pop(Stacks);
	return Layer4FromTop;	
}
/* This function returns Applicaiton Layer using pop and push.*/
struct Layer PeekAppLayer(struct Stack *Stacks){
	struct Layer Layer1FromTop = Peek(Stacks);
	Pop(Stacks);
	struct Layer Layer2FromTop = Peek(Stacks);
	Pop(Stacks);
	struct Layer Layer3FromTop = Peek(Stacks);
	Pop(Stacks);
	struct Layer Layer4FromTop = Peek(Stacks);
	Pop(Stacks);
	Push(Stacks,Layer4FromTop);
	Push(Stacks,Layer3FromTop);
	Push(Stacks,Layer2FromTop);
	Push(Stacks,Layer1FromTop);
	return Layer4FromTop;	
}
/* This function moves senders frames which is waiting on outqueue to in-queue of receiver.*/
void OutgoingToIncoming(struct Clients *Sender,struct Clients *Reciver){
	while(Sender->OQueueFront->Next != NULL){
		struct Stack *Stacks = &(Sender->OQueueFront->Stacks);
    	Sender->OQueueFront = Sender->OQueueFront->Next;
		InsertToInQueue(Reciver,Stacks);
	}
		struct Stack *Stacks = &(Sender->OQueueFront->Stacks);
    	Sender->OQueueFront = NULL;
    	Sender->OQueueRear = NULL;
		InsertToInQueue(Reciver,Stacks);
}
/* This function chane mac address of physical layer using pop and push.*/
void changeMacAdress(struct Stack *Stacks,char *Rmac,char *Nmac){
	struct Layer Layers = Peek(Stacks);
	Pop(Stacks);
	Layers.Area1 = Rmac;
	Layers.Area2 = Nmac;
	Push(Stacks,Layers);
}
/* This function moves frames from in-queue to out-queue.*/
struct Clients *IncomingToOutgoing(struct Clients *Reciver,struct Clients *FinalClient,struct Routings *RoutingsData,struct Clients *ClientsData,int totalClient, int MaxMsgSize){
	int i = 0;
	char *Message = calloc(DisplayInQueue(Reciver) * MaxMsgSize , sizeof(char*));
	while(Reciver->IQueueFront->Next != NULL){ /* Doing dequeue until last frame.*/
    	char *NextStop = findRouting(RoutingsData, totalClient, Reciver->Name, FinalClient->Name); /* I finds route for sending data.*/
    	if (strcmp(NextStop,"-") == 0){ /* İf sender client has no connection to receiver client, message drops here.*/
    		MessageDrop = 1; 
    		struct Stack *Stacks = &(Reciver->IQueueFront->Stacks);
    		Reciver->IQueueFront = Reciver->IQueueFront->Next;
    		struct Layer AppLayer = PeekAppLayer(Stacks);
    		strcat(Message,AppLayer.Area3);
			i++;
    	}else{ /* If sender client has route to receiver client;*/
    		struct Stack *Stacks = &(Reciver->IQueueFront->Stacks);
    		Reciver->IQueueFront = Reciver->IQueueFront->Next;
    		struct Clients *NextClient = searchClients(ClientsData,NextStop,totalClient);
    		changeMacAdress(Stacks,Reciver->Mac,NextClient->Mac);
    		printf("        Frame #%d MAC address change: New sender MAC %s, new receiver MAC %s\n", (++i),Reciver->Mac,NextClient->Mac);
			InsertToOutQueue(Reciver,Stacks);
			struct Layer AppLayer = PeekAppLayer(Stacks);
			strcat(Message,AppLayer.Area3);
		}
	}
	if (MessageDrop != 1){ /* If message had not dropped.*/
		struct Stack *Stacks = &(Reciver->IQueueFront->Stacks);
    	char *NextStop = findRouting(RoutingsData, totalClient, Reciver->Name, FinalClient->Name);
    	struct Clients *NextClient = searchClients(ClientsData,NextStop,totalClient);
    	changeMacAdress(Stacks,Reciver->Mac,NextClient->Mac);
    	printf("        Frame #%d MAC address change: New sender MAC %s, new receiver MAC %s\n", (++i),Reciver->Mac,NextClient->Mac);
    	Reciver->IQueueFront = NULL;
    	Reciver->IQueueRear = NULL;
		InsertToOutQueue(Reciver,Stacks);
		struct Layer AppLayer = PeekAppLayer(Stacks);
		strcat(Message,AppLayer.Area3);
		struct Log *Log = CreateLog(Reciver,Message,i,NumberOfHops,AppLayer.Area1,FinalClient->Name,"Message Forwarded","Yes");
		InsertLog(Reciver, Log);
		NumberOfHops++;
		Log = CreateLog(NextClient,Message,i,NumberOfHops,AppLayer.Area1,FinalClient->Name,"Message Received","Yes");
		InsertLog(NextClient, Log);
		return NextClient;
	}else{/* When message had been dropped.*/
		printf("Error: Unreachable destination. Packets are dropped after %d hops!\n", NumberOfHops);
		struct Stack *Stacks = &(Reciver->IQueueFront->Stacks);
    	Reciver->IQueueFront = Reciver->IQueueFront->Next;
    	struct Layer AppLayer = PeekAppLayer(Stacks);
		strcat(Message,AppLayer.Area3);
		struct Log *Log = CreateLog(Reciver,Message,(++i),NumberOfHops,AppLayer.Area1,FinalClient->Name,"Message Forwarded","No");
		InsertLog(Reciver, Log);
	}
}
/* This function send messages until arrive their destinations. */
void MessageSendingUntilEnd(struct Clients *ClientsData, struct Clients *ReceiverClient, int totalClient, struct Routings *RoutingsData, int MaxMsgSize){
	char *ReceiverIP = PeekIP(&(ReceiverClient->IQueueFront->Stacks));
	struct Clients *FinalClient = searchClientsByIP(ClientsData,ReceiverIP,totalClient);
	if(strcmp(ReceiverIP,ReceiverClient->Ip)==0){ /* It checks the IP of receiver for unpack or sending those frames. */
		/* If message arrive to receiver.*/
		char* Sender;
		char *Message = (char*) malloc(DisplayInQueue(ReceiverClient) * MaxMsgSize);
		while(ReceiverClient->IQueueFront->Next != NULL){
			struct Stack *Stacks = &(ReceiverClient->IQueueFront->Stacks);
    		ReceiverClient->IQueueFront = ReceiverClient->IQueueFront->Next;
    		struct Layer ApplicationLayer = PopAllStackAndReturnAppLayer(Stacks);
    		strcat(Message, ApplicationLayer.Area3);
		}
		struct Stack *Stacks = &(ReceiverClient->IQueueFront->Stacks);
    	ReceiverClient->IQueueFront = ReceiverClient->IQueueFront->Next;
    	struct Layer ApplicationLayer = PopAllStackAndReturnAppLayer(Stacks);
    	strcat(Message, ApplicationLayer.Area3);
    	Sender = ApplicationLayer.Area1;
    	printf("A message received by client %s from client %s after a total of %d hops.\n",ReceiverClient->Name,Sender,NumberOfHops);
		printf("Message: %s\n",Message);
	}else{
		/* If message had not arrived to receiver, function calls itself.*/
		printf("A message received by client %s, but intended for client %s. Forwarding...\n",ReceiverClient->Name,FinalClient->Name);
		struct Clients *NextClient = IncomingToOutgoing(ReceiverClient,FinalClient,RoutingsData,ClientsData,totalClient,MaxMsgSize);
		if (MessageDrop == 0){
			OutgoingToIncoming(ReceiverClient,NextClient);
			MessageSendingUntilEnd(ClientsData, NextClient, totalClient, RoutingsData, MaxMsgSize);
		}
	}
}
/* This function process all the commands which are in the command file. */
void processingOfCommands(struct Routings *RoutingsData, struct Clients *ClientsData, char* filePathOfCommands, char* filePathOfClients, char* MaxMsgSize, char* outPort, char* inPort){
	int totalCommands = getTotalCommands(filePathOfCommands);
	int totalClient = getTotalClient(filePathOfClients);
	FILE *commandFile;
	commandFile = fopen(filePathOfCommands, "r");
	char line[5000],parsedLine[5000], *commandType;
	int control,i,j;
	control = 0;
	char **partOfMessage;
	while ( fgets ( line, sizeof line, commandFile ) != NULL ){	
			if (control!=0){
				line [strcspn(line, "\r\n")] = 0;
				strcpy(parsedLine, line);
				commandType = strtok (parsedLine," ");
				if(strcmp(commandType,"MESSAGE") == 0){
					char *Sender = strtok (NULL," ");
					char *Receiver = strtok(NULL," ");
					char *Message = strtok(NULL,"#");
					printDash((strlen(line) + 10));
					printf("Command: %s\n",line); 
					printDash((strlen(line) + 10));
					int totalPart;
					if ((strlen(Message) % atoi(MaxMsgSize)) == 0){
						totalPart = strlen(Message) / atoi(MaxMsgSize);
					}else{
						totalPart = strlen(Message) / atoi(MaxMsgSize) + 1;
					}
					partOfMessage = malloc(totalPart * sizeof(char*));
					for (i = 0; i < totalPart; ++i){
						partOfMessage[i] = strndup(Message + atoi(MaxMsgSize) * i, atoi(MaxMsgSize));
					}
					struct Layer Layers[totalPart][4];
					char* NextStop = findRouting(RoutingsData, totalClient, Sender, Receiver);
					struct Clients *SenderClient = searchClients(ClientsData,Sender,totalClient);
					struct Clients *ReceiverClient = searchClients(ClientsData,Receiver,totalClient);
					if(strcmp(NextStop,"-") != 0){
						printf("Message to be sent: %s\n\n",Message);
						struct Clients *NextClient = searchClients(ClientsData,NextStop,totalClient);
						struct Stack MessageStacks[totalPart];
						for (i = 0; i < totalPart; ++i){
							Layers[i][3].LayerType = "PL";
							Layers[i][3].Area1 = SenderClient->Mac;
							Layers[i][3].Area2 = NextClient->Mac;
							Layers[i][2].LayerType = "NL";
							Layers[i][2].Area1 = SenderClient->Ip;
							Layers[i][2].Area2 = ReceiverClient->Ip;
							Layers[i][1].LayerType = "TL";
							Layers[i][1].Area1 = outPort;
							Layers[i][1].Area2 = inPort;
							Layers[i][0].LayerType = "AL";
							Layers[i][0].Area1 = SenderClient->Name;
							Layers[i][0].Area2 = ReceiverClient->Name;
							Layers[i][0].Area3 = partOfMessage[i];
							IntoTheStack(Layers[i], &MessageStacks[i], totalPart);
							InsertToOutQueue(SenderClient, &MessageStacks[i]);
							char DashCounter[40];
							sprintf(DashCounter, "%d", i);
							printf("Frame #%d\n", (i + 1));
							Display(&MessageStacks[i]);
							printDash((strlen(DashCounter) + 7));
						}
					}else{
						printf("\tThere is no way to send any frame between this two nodes, therefore there is no frame created.\n");
						char* LogMessage = malloc(1500 * sizeof(char));
						for (i = 0; i < totalPart; ++i){
							strcat(LogMessage,partOfMessage[i]);
						}
						struct Log *Log = CreateLog(SenderClient,LogMessage,0,NumberOfHops,SenderClient->Name,ReceiverClient->Name,"Message Sent","No");
						InsertLog(SenderClient, Log);
					}
				}else if(strcmp(commandType,"SHOW_FRAME_INFO") == 0){
					char *QClient = strtok (NULL," ");
					char *QueueType = strtok(NULL," ");
					int FrameNumber = atoi(strtok(NULL," "));
					struct Clients ClientCopy = searchClientsByValue(ClientsData,QClient,totalClient);
					struct Clients *ClientPointer = searchClients(ClientsData,QClient,totalClient);
					if(strcmp(QueueType,"out") == 0){
						int totalFrames = DisplayOutQueue(ClientPointer);
						if (FrameNumber<=totalFrames){
							printDash((strlen(line) + 10));
							printf("Command: %s\n",line);
							printDash((strlen(line) + 10));
							struct Queue *ClientsQueue;
							for (i = 0; i < FrameNumber; ++i){
								ClientsQueue = ClientCopy.OQueueFront;
        						ClientCopy.OQueueFront = ClientCopy.OQueueFront->Next;
							}
							struct Stack *IStack = &(ClientsQueue->Stacks);
							printf("Current Frame #%d on the outgoing queue of client %s\n",FrameNumber, ClientCopy.Name);
							printf("Carried Message: \"%s\"\n", IStack->Layers[0].Area3);
							printf("Layer 0 info: Sender ID: %s, Receiver ID: %s\n", IStack->Layers[0].Area1,IStack->Layers[0].Area2);
							printf("Layer 1 info: Sender port number: %s, Receiver port number: %s\n", IStack->Layers[1].Area1,IStack->Layers[1].Area2);
							printf("Layer 2 info: Sender IP address: %s, Receiver IP address: %s\n", IStack->Layers[2].Area1,IStack->Layers[2].Area2);
							printf("Layer 3 info: Sender MAC address: %s, Receiver MAC address: %s\n", IStack->Layers[3].Area1,IStack->Layers[3].Area2);
							printf("Number of hops so far: %d\n", NumberOfHops);
						}else{
							printDash((strlen(line)) + 10);
							printf("Command: %s\n",line);
							printDash((strlen(line)) + 10);
							printf("No such frame.\n");
						}
					}else{
						int totalFrames = DisplayInQueue(ClientPointer);
						if (FrameNumber<=totalFrames){
							printDash((strlen(line)) + 10);
							printf("Command: %s\n",line);
							printDash((strlen(line)) + 10);
							struct Queue *ClientsQueue;
							for (i = 0; i < FrameNumber; ++i){
								ClientsQueue = ClientCopy.IQueueFront;
        						ClientCopy.IQueueFront = ClientCopy.IQueueFront->Next;
							}
							struct Stack *IStack = &(ClientsQueue->Stacks);
							printf("Current Frame #%d on the outgoing queue of client %s\n",FrameNumber, ClientCopy.Name);
							printf("Carried Message: \"%s\"\n", IStack->Layers[0].Area3);
							printf("Layer 0 info: Sender ID: %s, Receiver ID: %s\n", IStack->Layers[0].Area1,IStack->Layers[0].Area2);
							printf("Layer 1 info: Sender port number: %s, Receiver port number: %s\n", IStack->Layers[1].Area1,IStack->Layers[1].Area2);
							printf("Layer 2 info: Sender IP address: %s, Receiver IP address: %s\n", IStack->Layers[2].Area1,IStack->Layers[2].Area2);
							printf("Layer 3 info: Sender MAC address: %s, Receiver MAC address: %s\n", IStack->Layers[3].Area1,IStack->Layers[3].Area2);
							printf("Number of hops so far: %d\n", NumberOfHops);
						}else{
							printDash((strlen(line)) + 10);
							printf("Command: %s\n",line);
							printDash((strlen(line)) + 10);
							printf("No such frame.\n");
						}
					}
				}else if(strcmp(commandType,"SHOW_Q_INFO") == 0){
					char *QClient = strtok (NULL," ");
					char *QueueType = strtok(NULL," ");
					int totalFrames;
					char *QueueTypePrint;
					struct Clients *ClientForQueue = searchClients(ClientsData,QClient,totalClient);
					if(strcmp(QueueType,"in") == 0){
						totalFrames = DisplayInQueue(ClientForQueue);
						QueueTypePrint = "Incoming";
					}else{
						totalFrames = DisplayOutQueue(ClientForQueue);
						QueueTypePrint = "Outgoing";
					}
					printDash((strlen(line)) + 10);
					printf("Command: %s\n",line);
					printDash((strlen(line)) + 10);
					printf("Client %s %s Queue Status\nCurrent total number of frames: %d\n",ClientForQueue->Name,QueueTypePrint,totalFrames);
				}else if(strcmp(commandType,"SEND") == 0){
					printDash((strlen(line)) + 10);
					printf("Command: %s\n",line);
					printDash((strlen(line)) + 10);
					char *Sender = strtok (NULL," ");
					struct Clients *SenderClient = searchClients(ClientsData,Sender,totalClient);
					if(DisplayOutQueue(SenderClient) > 0){ /* It checks for given clients has frames or not.*/
						struct Stack *FirstStack = PeekFirstFrame(SenderClient);
						char* IP = PeekIP(FirstStack);
						struct Layer Layer = Peek(FirstStack);
						struct Clients *ReceiverClient = searchClientsByMac(ClientsData,Layer.Area2,totalClient);
						struct Clients *FinalClient = searchClientsByIP(ClientsData,IP,totalClient);
						int totalPart = DisplayOutQueue(SenderClient);
						struct Clients ClientCopy = searchClientsByValue(ClientsData,Sender,totalClient);
						struct Queue *ClientsQueue;
						char* LogMessage = malloc(1500 * sizeof(char));
						for (i = 0; i < totalPart; ++i){
							ClientsQueue = ClientCopy.OQueueFront;
        					ClientCopy.OQueueFront = ClientCopy.OQueueFront->Next;
        					struct Stack *IStack = &(ClientsQueue->Stacks);
        					struct Layer AppLayer = PeekAppLayer(IStack);
        					strcat(LogMessage,AppLayer.Area3);
						}
						OutgoingToIncoming(SenderClient,ReceiverClient);
						struct Log *Log = CreateLog(SenderClient,LogMessage,totalPart,NumberOfHops,SenderClient->Name,FinalClient->Name,"Message Sent","Yes");
						InsertLog(SenderClient, Log);
						NumberOfHops++;
						Log = CreateLog(ReceiverClient,LogMessage,totalPart,NumberOfHops,SenderClient->Name,FinalClient->Name,"Message Received","Yes");
						InsertLog(ReceiverClient, Log);
						MessageSendingUntilEnd(ClientsData,ReceiverClient,totalClient,RoutingsData,atoi(MaxMsgSize));
					}else{
						printf("\tThere is no frame for sending.\n");
					}
				}else if(strcmp(commandType,"PRINT_LOG") == 0){
					char *Log = strtok (NULL," ");
					struct Clients *LogClient = searchClients(ClientsData,Log,totalClient);
					if(LogClient->totalLog > 0){ /* Prints logs if exits.*/
					printDash((strlen(line)) + 10);
					printf("Command: %s\n",line);
					printDash((strlen(line)) + 10);
					printf("Client %s Logs:\n",Log);
					DisplayLogs(LogClient);
					}else{
					printDash((strlen(line)) + 10);
					printf("Command: %s\n",line);
					printDash((strlen(line)) + 10);
					printf("Client %s Logs:\n",Log);
					printf("\tNo Logs!\n");
					}
				}else{
					printDash((strlen(line)) + 10);
					printf("Command: %s\n",line);
					printDash((strlen(line)) + 10);
					printf("Invalid command.\n");
				}
			}else{
				control = 1;
			}
	}
	fclose(commandFile);
}