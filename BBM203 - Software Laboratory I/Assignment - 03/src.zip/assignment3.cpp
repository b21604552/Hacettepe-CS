#include <iostream>
#include <fstream>
#include <cstring>
#include <cstdlib>
#include <stdlib.h>
#include <string.h>
#include <sstream>
using namespace std;
struct footballerStatistics{
	string awayTeam;
	int minuteOfGoal;
	int matchID;
	footballerStatistics* prev;
	footballerStatistics* next;
};
struct footballer{
    string footballerName;
   	string footballerTeam;
   	footballerStatistics* head;
    footballer* next;
};
footballer *head = NULL;
char* outputFile = NULL;
/*This function adds created footballer to linked list.*/
void addFootballer(char* name,char* team,char* awayTeam,int minuteOfGoal,int matchID){
	footballer *newFootballer = new footballer;
	newFootballer->footballerName = name;
	newFootballer->footballerTeam = team;
	footballerStatistics *newStatistics = new footballerStatistics;
	newStatistics->awayTeam = awayTeam;
	newStatistics->minuteOfGoal = minuteOfGoal;
	newStatistics->matchID = matchID;
	newFootballer->head = newStatistics;
	newFootballer->next = NULL;
	if(head == NULL) {
		head = newFootballer;
		return;
	}else{
		if(head->footballerName > name){
			newFootballer->next = head;
			head = newFootballer;
		}else{
			footballer *temp = head;
			while(temp->next != NULL && temp->next->footballerName < name){
				temp = temp->next;
			}
			if(temp->next == NULL){
				newFootballer->next = NULL;
				temp->next = newFootballer;
			}else{
				newFootballer->next = temp->next;
				temp->next = newFootballer;
			}
		}
	}
}
/*This function create the output file.*/
void createFile(){
	ofstream output;
	output.open(outputFile);
	output.close();
}
/*This function append the given line to output file.*/
void printToFile(string line){
	ofstream output;
	output.open(outputFile,std::ios_base::app);
	output << line;
	output.close();
}
/*This function returns 1 if given footballer name in the likned list.*/
int search(string name){
	footballer *cur = head;
	while(cur) {
		if(!cur->footballerName.compare(name)) {
			return 1;
		}
		cur = cur->next;
	}
	return 0;
}
/*This function returns footballer pointer which is point to given footballer name.*/
footballer* getFootballer(string name){
	footballer *cur = head;
	while(cur) {
		if(!cur->footballerName.compare(name)) {
			return cur;
		}
		cur = cur->next;
	}
}
/* This function create statistic information variable and add it to given footballers statistic 
	linked list according to matchID.*/
void addStatistic(footballer* head,char* awayTeam,int minuteOfGoal,int matchID){
	footballerStatistics *newStatistics = new footballerStatistics;
	footballerStatistics *current; 
	newStatistics->awayTeam = awayTeam;
	newStatistics->minuteOfGoal = minuteOfGoal;
	newStatistics->matchID = matchID;
	if (head->head->matchID > newStatistics->matchID) { 
        newStatistics->next = head->head; 
        newStatistics->next->prev = newStatistics; 
        head->head = newStatistics; 
    }else if (head->head->matchID < newStatistics->matchID){
		current = head->head;
    	while (current->next != NULL && current->next->matchID <= newStatistics->matchID) 
       		current = current->next;
        newStatistics->next = current->next; 
        if (current->next != NULL) 
        	newStatistics->next->prev = newStatistics; 
        current->next = newStatistics; 
        newStatistics->prev = current;
    }else{
    	if (head->head->minuteOfGoal >= newStatistics->minuteOfGoal) { 
        	newStatistics->next = head->head;
        	newStatistics->next->prev = newStatistics; 
        	head->head = newStatistics;
        }else{
        	current = head->head;
    		while (current->next != NULL && current->next->minuteOfGoal < newStatistics->minuteOfGoal && current->next->matchID == newStatistics->matchID) 
       			current = current->next;
        	newStatistics->next = current->next; 
        	if (current->next != NULL) 
            	newStatistics->next->prev = newStatistics; 
        	current->next = newStatistics; 
        	newStatistics->prev = current;
        }
    }
}
/*This function sort the given statistics using bubble sort algorithm.*/
void bubbleSort(footballerStatistics *start){ 
    int swapped, i; 
    footballerStatistics *ptr1; 
    footballerStatistics *lptr = NULL; 
    do{ 
        swapped = 0; 
        ptr1 = start;
        while (ptr1->next != lptr){
            if (ptr1->minuteOfGoal > ptr1->next->minuteOfGoal && ptr1->matchID == ptr1->next->matchID){ 
                swap(ptr1->minuteOfGoal, ptr1->next->minuteOfGoal); 
                swapped = 1; 
            } 
            ptr1 = ptr1->next; 
        } 
        lptr = ptr1; 
    }
    while (swapped); 
}
/*This function send first statistic of footballer to bubble sort function.*/
void sortStatistics(){
	footballer *temp = head;
	int i = 0;
	while(temp != NULL){
		footballerStatistics *temp1 = temp->head;
		bubbleSort(temp1);
		temp = temp->next;
	}
}
/*This function returns the number of footballers in input file.*/
int getTotalFootballer(char* filePath){
	FILE *inputFile;
	inputFile = fopen(filePath, "r");
	char line[300];
	int i = 0;
	while ( fgets ( line, sizeof line, inputFile ) != NULL ){
		if(line != "\n")
			i++;
	}
	fclose(inputFile);
	return i;
}
/*This function gets the informations about footballers from input file then create a variable which is type footballer,
	then add it to linked list in alphabetic order.*/
void getFootballerInfo(char* filePath){
	FILE *inputFile;
	inputFile = fopen(filePath, "r");
	char line[300];
	char *name,*team,*awayTeam;
	int minuteOfGoal,matchID,i = 0;
	while ( fgets ( line, sizeof line, inputFile ) != NULL ){
		line[strcspn(line, "\r\n")] = 0;
		if(strlen(line) > 1 ){
			name = strtok (line,",");
			team = strtok (NULL,",");
			awayTeam = strtok (NULL,",");
			minuteOfGoal = atoi(strtok (NULL,","));
			matchID = atoi(strtok (NULL,","));
			if (search(name) == 0)
				addFootballer(name,team,awayTeam,minuteOfGoal,matchID);
			else{
				footballer* found = getFootballer(name);
				addStatistic(found,awayTeam,minuteOfGoal,matchID);
			}
		}
	}
	fclose(inputFile);
}
/*This function print-out the most scored half to output file.*/
void mostScoredHalf(){
	printToFile("1)THE MOST SCORED HALF\n");
	int firstHalf = 0;
	int secondHalf = 0;
    footballer *temp = head;
    while(temp != NULL){
     	footballerStatistics *temp1 = temp->head;
    	while(temp1 != NULL){
    		if (temp1->minuteOfGoal <= 45){
    			firstHalf++;
    		}else{
    			secondHalf++;
    		}
    		temp1 = temp1->next;
      	}
      	temp = temp->next;
    }
    if (firstHalf < secondHalf){
    	printToFile("1\n");
    }else{
    	printToFile("0\n");
    }
}
/*This function print-out the most scroed footballer or footballers to output file.*/
void goalScorer(){
	printToFile("2)GOAL SCORER\n");
	footballer *temp = head;
	int prevScore = 0;
	int score = 0;
	string topScorer = "";
    while(temp != NULL){
     	footballerStatistics *temp1 = temp->head;
    	while(temp1 != NULL){
    		score++;
    		temp1 = temp1->next;
      	}
      	if(score > prevScore){
      		topScorer = temp->footballerName + "\n";
      		prevScore = score;
      	}else if(score == prevScore){
      		topScorer = topScorer + temp->footballerName + "\n";
      	}
      	score = 0;
      	temp = temp->next;
    }
    printToFile(topScorer);
}
/*This function print-out players who are scored more than two goals in a match.*/
void hattrick(){
	footballer *temp = head;
	printToFile("3)THE NAMES OF FOOTBALLERS WHO SCORED HAT-TRICK\n");
    while(temp != NULL){
     	footballerStatistics *temp1 = temp->head;
    	while(temp1 != NULL){
			if((temp1) && (temp1->next) && (temp1->next->next) && (temp1->matchID == temp1->next->matchID) && (temp1->matchID == temp1->next->next->matchID)){
    			printToFile(temp->footballerName + "\n");
    			break;
    		}
    		temp1 = temp1->next;
      	}
      	temp = temp->next;
    }
}
/*This function returns 1 if given team names have been already added to given array.*/
int searchTeam(int numberOfFootballer, string teams[], string name){
	int i = 0;
	while(teams[i] != ""){
		if(teams[i] == name)
			return 1;
		i++;
	}
	return 0;
}
/*This function print-out teams whom has scored footballer.*/
void listOfTeams(char* filePath){
	printToFile("4)LIST OF TEAMS\n");
	int totalFootballer = 0;
	totalFootballer = getTotalFootballer(filePath);
	string teams[totalFootballer];
	footballer *temp = head;
	int control;
	int i = 0;
    while(temp != NULL){
    	control = searchTeam(totalFootballer,teams,temp->footballerTeam);
    	if(control == 0)
    		teams[i++] = temp->footballerTeam;
    	temp = temp->next;
    }
    i = 0;
    while(teams[i] != ""){
    	printToFile(teams[i++] + "\n");
    }
}
/*This function print-out all the footballers in linked list.*/
void listOfFootballers(){
	printToFile("5)LIST OF FOOTBALLERS\n");
	footballer *temp = head;
    while(temp != NULL){
     	printToFile(temp->footballerName + "\n");
      	temp = temp->next;
    }
}
/*This function print-out given footballers match.*/
void matchOfGivenFootballer(string name){
	footballer* footballer = getFootballer(name);
	footballerStatistics* footballerStatistic = footballer->head;
	printToFile("Matches of " + footballer->footballerName + "\n");
	while(footballerStatistic != NULL){
		stringstream temp;
		stringstream temp1;
		temp << footballerStatistic->minuteOfGoal;
		temp1 << footballerStatistic->matchID;
     	printToFile("Footballer Name: " + footballer->footballerName + ",Away Team: " + footballerStatistic->awayTeam + ",Min of Goal: " + temp.str() + ",Match ID: " + temp1.str() + "\n");
      	footballerStatistic = footballerStatistic->next;
    }
}
/*This function print-out given footballers match asc. order.*/
void ascOrderOfMatchID(string name){
	footballer* footballer = getFootballer(name);
	footballerStatistics* footballerStatistic = footballer->head;
	while((footballerStatistic != NULL)){
		stringstream temp;
		temp << footballerStatistic->matchID;
		if((footballerStatistic->next == NULL) || (footballerStatistic->next->matchID != footballerStatistic->matchID)){
			printToFile("footballer Name: " + footballer->footballerName + ",Match ID: " + temp.str() + "\n");
		}
		footballerStatistic = footballerStatistic->next;
	}
}
/*This function make it reverse given footballer statistic.*/
footballerStatistics* reverse(footballerStatistics* head){
    footballerStatistics* curr = head; 
    footballerStatistics* prev = NULL;
    footballerStatistics* next = NULL;
    while(curr)
    {
        next = curr->next;
        curr->next = prev;
    	curr->prev = next;
        prev = curr;
        curr = next;
    }
    return head=prev;
}
/*This function print-out given footballers match desc. order.*/
void descOrderOfMatchID(string name,int i){
	footballer* foundFootballer = getFootballer(name);
	footballerStatistics* reversed = reverse(foundFootballer->head);
	foundFootballer->head = reversed;
	while(foundFootballer->head != NULL){
		stringstream temp;
		temp << foundFootballer->head->matchID;
		if((foundFootballer->head->prev == NULL) || (foundFootballer->head->prev->matchID != foundFootballer->head->matchID))
			if((i == 0) || (foundFootballer->head->next != NULL))
				printToFile("footballer Name: " + foundFootballer->footballerName + ",Match ID: " + temp.str() + "\n");
			else if(foundFootballer->head->next == NULL)
				printToFile("footballer Name: " + foundFootballer->footballerName + ",Match ID: " + temp.str());
		foundFootballer->head = foundFootballer->head->next;
	}
}
/*This function calls the functions which are about operations file.*/
void operations(char* filePath){
	FILE *inputFile;
	inputFile = fopen(filePath, "r");
	char line[300];
	char *footballer1,*footballer2;
	int control = 0;
	while ( fgets ( line, sizeof line, inputFile ) != NULL ){
		line[strcspn(line, "\r\n")] = 0;
		if(strlen(line) > 1 ){
			footballer1 = strtok (line,",");
			footballer2 = strtok (NULL,",");
			if(control == 0){
				printToFile("6)MATCHES OF GIVEN FOOTBALLER\n");
				matchOfGivenFootballer(footballer1);
				matchOfGivenFootballer(footballer2);
				control++;
			}else if(control == 1){
				printToFile("7)ASCENDING ORDER ACCORDING TO MATCH ID\n");
				ascOrderOfMatchID(footballer1);
				ascOrderOfMatchID(footballer2);
				control++;
			}else{
				printToFile("8)DESCENDING ORDER ACCORDING TO MATCH ID\n");
				descOrderOfMatchID(footballer1,0);
				descOrderOfMatchID(footballer2,1);
			}
		}
	}
	fclose(inputFile);
}
int main(int argc, char **argv) {
	outputFile = argv[3];
	createFile();
	getFootballerInfo(argv[1]);
	sortStatistics();
	mostScoredHalf();
	goalScorer();
	hattrick();
	listOfTeams(argv[1]);
	listOfFootballers();
	operations(argv[2]);
	return 0;
}
