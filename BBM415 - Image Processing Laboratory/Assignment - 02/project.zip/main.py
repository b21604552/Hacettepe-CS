from filters import gaussianFilter, meanFilter, kuwaharaFilter

images = ["france", "autumn", "fallingWater", "storm", "woods"]
windowSizes = [3, 5, 7, 9]

for imageName in images:
    for windowSize in windowSizes:
        print("a")
        meanFilter(imageName, windowSize)
        print("b")
        gaussianFilter(imageName, windowSize, 1)
        gaussianFilter(imageName, windowSize, 2)
        kuwaharaFilter(imageName, windowSize)
