import numpy as np
from os import getcwd


def getOutputPath(type, image, windowSize, sigma):
    if type == "gaussian":
        return getcwd() + "/images/output/gaussian/" + str(image) + "_" + str(windowSize) + "_" + str(sigma) + ".jpg"

    elif type == "mean":
        return getcwd() + "/images/output/mean/" + str(image) + "_" + str(windowSize) + ".jpg"

    elif type == "kuwahara":
        return getcwd() + "/images/output/kuwahara/" + str(image) + "_" + str(windowSize) + ".jpg"


def getInputPath(image):
    return getcwd() + "/images/input/" + str(image) + ".jpg"


def getRowStart(minStd, row, height):
    switcher = {
        0: row - height // 2,
        1: row - height // 2,
        2: row,
        3: row,
    }
    return switcher.get(minStd)


def getRowEnd(minStd, row, height):
    switcher = {
        0: row + 1,
        1: row + 1,
        2: row + height // 2 + 1,
        3: row + height // 2 + 1,
    }
    return switcher.get(minStd)


def getColumnStart(minStd, column, width):
    switcher = {
        0: column,
        1: column - width // 2,
        2: column - width // 2,
        3: column,
    }
    return switcher.get(minStd)


def getColumnEnd(minStd, column, width):
    switcher = {
        0: column + width // 2 + 1,
        1: column + 1,
        2: column + 1,
        3: column + width // 2 + 1,
    }
    return switcher.get(minStd)


def rgbChange(image, row, column, rowStart, rowEnd, columnStart, columnEnd):
    image[row][column][0] = np.mean(image[rowStart: rowEnd, columnStart: columnEnd, 0])
    image[row][column][1] = np.mean(image[rowStart: rowEnd, columnStart: columnEnd, 1])
    image[row][column][2] = np.mean(image[rowStart: rowEnd, columnStart: columnEnd, 2])
