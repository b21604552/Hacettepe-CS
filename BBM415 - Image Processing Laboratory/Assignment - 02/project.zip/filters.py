from PIL import Image
from helpers import *


def meanFilter(imageName, windowSize):
    image = Image.open(getInputPath(imageName))
    width, height = image.size
    windowValue = int((windowSize - 1) / 2)
    width = int(width - windowValue)
    height = int(height - windowValue)
    for i in range(windowValue, width):
        for j in range(windowValue, height):
            r, g, b = 0, 0, 0
            for k in range(-windowValue, windowValue + 1):
                for l in range(-windowValue, windowValue + 1):
                    r = r + image.getpixel((i + k, j + l))[0]
                    g = g + image.getpixel((i + k, j + l))[1]
                    b = b + image.getpixel((i + k, j + l))[2]
            r, g, b = int(r / (windowSize ** 2)), int(g / (windowSize ** 2)), int(b / (windowSize ** 2))
            image.putpixel((i, j), (r, g, b))
    image.save(getOutputPath("mean", imageName, windowSize, ""))


def gaussianFilter(imageName, windowSize, sigma):
    image = Image.open(getInputPath(imageName))
    rangeValue = int((windowSize - 1) / 2)
    gaussianMask = np.zeros((windowSize, windowSize))
    for i in range(-rangeValue, rangeValue + 1):
        for j in range(-rangeValue, rangeValue + 1):
            varX = sigma ** 2 * (2 * np.pi)
            varY = np.exp(-(i ** 2 + j ** 2) / (2 * sigma ** 2))
            gaussianMask[i + rangeValue, j + rangeValue] = (1 / varX) * varY

    width, height = image.size
    width = int(width - rangeValue)
    height = int(height - rangeValue)
    for i in range(rangeValue, width):
        for j in range(rangeValue, height):
            r, g, b = 0, 0, 0
            for k in range(-rangeValue, rangeValue + 1):
                for l in range(-rangeValue, rangeValue + 1):
                    r = (r + (image.getpixel((i + k, j + l))[0] * gaussianMask[k + rangeValue][l + rangeValue]))
                    g = (g + (image.getpixel((i + k, j + l))[1] * gaussianMask[k + rangeValue][l + rangeValue]))
                    b = (b + (image.getpixel((i + k, j + l))[2] * gaussianMask[k + rangeValue][l + rangeValue]))
            image.putpixel((i, j), (int(r), int(g), int(b)))
    image.save(getOutputPath("gaussian", imageName, windowSize, sigma))


def kuwaharaFilter(imageName, windowSize):
    rgbImage = np.array(Image.open(getInputPath(imageName)), dtype=float)
    hsvImage = np.array(Image.open(getInputPath(imageName)).convert("HSV"), dtype=float)
    imageWidth, imageHeight, imageChannel = hsvImage.shape
    paddingValue = windowSize // 2
    for row in range(paddingValue, imageWidth - paddingValue):
        for column in range(paddingValue, imageHeight - paddingValue):
            imagePart = hsvImage[row - paddingValue: row + paddingValue + 1, column - paddingValue: column + paddingValue + 1, 2]
            width, height = imagePart.shape
            Q1 = imagePart[0: height // 2 + 1, width // 2: width]
            Q2 = imagePart[0: height // 2 + 1, 0: width // 2 + 1]
            Q3 = imagePart[height // 2: height, 0: width // 2 + 1]
            Q4 = imagePart[height // 2: height, width // 2: width]
            stds = np.array([np.std(Q1), np.std(Q2), np.std(Q3), np.std(Q4)])
            minStd = stds.argmin()
            rowStart = getRowStart(minStd, row, height)
            rowEnd = getRowEnd(minStd, row, height)
            columnStart = getColumnStart(minStd, column, width)
            columnEnd = getColumnEnd(minStd, column, width)
            rgbChange(rgbImage, row, column, rowStart, rowEnd, columnStart, columnEnd)
    Image.fromarray(rgbImage.astype(np.uint8)).save(getOutputPath("kuwahara", imageName, windowSize, ""))
