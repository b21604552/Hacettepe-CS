# CHANGELOG.md

## [1.0.0] - 2021-04-20

First release